export default [
  require("/home/claude/iodoom/website/.docusaurus/docusaurus-plugin-css-cascade-layers/default/layers.css"),
  require("/home/claude/iodoom/website/node_modules/infima/dist/css/default/default.css"),
  require("/home/claude/iodoom/website/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/home/claude/iodoom/website/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/home/claude/iodoom/website/src/css/custom.css"),
];
