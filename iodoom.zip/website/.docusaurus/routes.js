import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/iodoom/markdown-page',
    component: ComponentCreator('/iodoom/markdown-page', '0bc'),
    exact: true
  },
  {
    path: '/iodoom/docs',
    component: ComponentCreator('/iodoom/docs', 'b13'),
    routes: [
      {
        path: '/iodoom/docs',
        component: ComponentCreator('/iodoom/docs', '90d'),
        routes: [
          {
            path: '/iodoom/docs',
            component: ComponentCreator('/iodoom/docs', '857'),
            routes: [
              {
                path: '/iodoom/docs/api',
                component: ComponentCreator('/iodoom/docs/api', 'a4b'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/building',
                component: ComponentCreator('/iodoom/docs/building', '3b9'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/configuration',
                component: ComponentCreator('/iodoom/docs/configuration', '44f'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/contributing',
                component: ComponentCreator('/iodoom/docs/contributing', '1c1'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/controls',
                component: ComponentCreator('/iodoom/docs/controls', '9f4'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/intro',
                component: ComponentCreator('/iodoom/docs/intro', 'e22'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/porting',
                component: ComponentCreator('/iodoom/docs/porting', '3d5'),
                exact: true,
                sidebar: "docsSidebar"
              },
              {
                path: '/iodoom/docs/wad-files',
                component: ComponentCreator('/iodoom/docs/wad-files', '7d3'),
                exact: true,
                sidebar: "docsSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/iodoom/',
    component: ComponentCreator('/iodoom/', 'c1f'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
